import image1 from '../images/1.png';
import image2 from '../images/2.png';
import image3 from '../images/3.png';
import image4 from '../images/4.png';
import image5 from '../images/5.png';
import image6 from '../images/6.png';
import image7 from '../images/7.png';
import image8 from '../images/8.png';

const images = [image1, image1, image2, image2, image3, image3, image4, image4, image5, image5, image6, image6, image7, image7, image8, image8];
export default images;