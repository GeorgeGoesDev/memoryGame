import './App.css';
import Tablero from './components/Tablero';

function App() {
  return (
   <div className='container'>
      <Tablero />
   </div>
  );
}

export default App;
